package rtspclient

const MEDIA_CLIENT_VERSION = "1.0.0.3"
