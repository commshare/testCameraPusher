#!/usr/bin/env bash

go run dor_media_player.go rtsp://192.168.1.101:8554/test.264
